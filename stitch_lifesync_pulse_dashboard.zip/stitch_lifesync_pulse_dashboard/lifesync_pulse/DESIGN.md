---
name: LifeSync Pulse
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#4cd7f6'
  on-tertiary: '#003640'
  tertiary-container: '#009eb9'
  on-tertiary-container: '#002f38'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  gutter-mobile: 0.75rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system targets high-achieving college students navigating academics, social commitments, wellness, and daily logistics. The visual identity fuses the polish of modern enterprise productivity tools with the youthful, electric energy of consumer lifestyle apps. 

The aesthetic is anchored in **Premium Dark Glassmorphism** layered over deep space-navy backgrounds. The emotional experience is designed to replace student overwhelm with hyper-focus, agency, and momentum. Luminescent gradients, glowing visual gauges, and crisp geometric structures provide tactile feedback and continuous visual reward without slipping into visual noise or novelty.

## Colors

The foundation is built on deep navy voids (`#0B0F19` base canvas, `#0D1527` elevated surface), allowing bright multi-chromatic accents to pop with high functional legibility.

### Accent & Signal Colors
- **Electric Purple (`#8B5CF6`):** Primary interaction point, active states, focus sessions, and primary call-to-actions.
- **Neon Blue (`#3B82F6`):** Secondary workflows, scheduled events, syllabus tracking, and informational indicators.
- **Vibrant Cyan (`#06B6D4`):** Tertiary accents, completion rings, micro-metrics, and streak milestones.
- **Electric Mint (`#10B981`):** Success states, fully checked habits, and passing grades.
- **High-Voltage Amber (`#F59E0B`):** Impending deadlines (due in < 24h) and high-priority alarms.
- **Neon Coral (`#F43F5E`):** Critical urgency, overdue milestones, and stress metrics.

### Neutral & Glass Tokens
- **Canvas Base:** `#0B0F19`
- **Surface Elevation 1 (Card Base):** `rgba(13, 21, 39, 0.75)` with `backdrop-filter: blur(16px)`
- **Surface Elevation 2 (Floating Popover/Modal):** `rgba(17, 27, 49, 0.85)` with `backdrop-filter: blur(24px)`
- **Frosted Border Line:** `rgba(255, 255, 255, 0.08)`
- **Frosted Highlight (Top Edge):** `rgba(255, 255, 255, 0.16)`
- **Text Primary:** `#F8FAFC`
- **Text Secondary:** `#94A3B8`
- **Text Muted:** `#64748B`

## Typography

Plus Jakarta Sans is used across all typographic hierarchies. Its geometric construction keeps dashboard metrics structured and legible at small sizes, while its subtle rounded terminals provide a modern, approachable edge suitable for collegiate life management.

### Key Rules
- **Numerical Metrics & Data:** Apply tabular figures (`font-feature-settings: 'tnum' on, 'cv05' on`) to timers, GPA indicators, grade weights, and time-block cards to prevent layout shifts.
- **Priority Labels:** `label-sm` applies uppercase styling with `letter-spacing: 0.06em` to maintain legibility when wrapped in pill badges.
- **Hero & Title Display:** `headline-xl` pairs with an ambient text-gradient (`linear-gradient(135deg, #FFFFFF 0%, #94A3B8 100%)`) on high-level dashboard overviews.

## Layout & Spacing

The layout is built on a 12-column fluid grid system across desktop views, shifting to a 6-column layout on tablet, and a 4-column system on mobile.

- **Desktop (1200px+):** 12 columns, `1.5rem` gutters, `2rem` page margins. Max content container is capped at `1440px`.
- **Tablet (768px – 1199px):** 6 columns, `1rem` gutters, `1.5rem` outer margins. Collapsible left-navigation rail to maximize canvas for calendar and schedule timelines.
- **Mobile (< 768px):** 4 columns, `0.75rem` gutters, `1rem` margins. Single-column card stacking with horizontal overflow snapping for micro-metric badges and category filters.

## Elevation & Depth

Visual depth is achieved through glassmorphism, directional edge highlights, and colored ambient glows rather than standard black drop shadows.

### Glass Surfaces & Hierarchy
- **Level 0 (Canvas):** Solid background color `#0B0F19` accented with subtle radial background gradients (`rgba(139, 92, 246, 0.08)` and `rgba(59, 130, 246, 0.06)`) positioned behind primary widgets.
- **Level 1 (Cards & Schedule Modules):** `rgba(13, 21, 39, 0.7)` with `backdrop-filter: blur(16px)` and `-webkit-backdrop-filter: blur(16px)`. Enclosed with a uniform border `1px solid rgba(255, 255, 255, 0.08)`.
- **Level 2 (Hover States & Active Focus Modules):** `rgba(17, 27, 49, 0.85)` with `backdrop-filter: blur(20px)`. Outer shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.5), 0 0 16px 0 rgba(139, 92, 246, 0.15)`.
- **Level 3 (Modals, Context Sheets, Command Palettes):** `rgba(15, 23, 42, 0.95)` with `backdrop-filter: blur(24px)`. Outer shadow: `0 24px 48px -12px rgba(0, 0, 0, 0.7), 0 0 24px 0 rgba(59, 130, 246, 0.2)`.

### Directional Border Highlight
Interactive elements feature an inset directional light gradient across their top border: `linear-gradient(90deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0.04) 100%)`.

## Shapes

The design system uses a controlled rounded geometry to balance structural data layout with friendly, human-centric hardware aesthetics.

- **Main Dashboard Cards:** Standardized to `1.25rem` (20px) to `1.5rem` (24px) corner radii for clean separation of complex widgets.
- **Nested Inner Containers & List Rows:** Standardized to `0.75rem` (12px) to `1rem` (16px).
- **Interactive Controls (Inputs, Buttons):** `0.75rem` (12px) to preserve target clarity.
- **Pills, Progress Bars, and Status Badges:** Fully rounded (`rounded-full` / 9999px) for continuous, biological feedback loops.

## Components

### Buttons
- **Primary:** Linear gradient (`135deg, #8B5CF6 0%, #3B82F6 100%`), white text, `0.75rem` radius, with a diffuse outer glow on hover: `box-shadow: 0 0 20px rgba(139, 92, 246, 0.45)`.
- **Secondary Glass:** `rgba(255, 255, 255, 0.05)` fill, `1px solid rgba(255, 255, 255, 0.12)` border, text `#F8FAFC`. On hover: `background: rgba(255, 255, 255, 0.1)`.
- **Ghost:** Transparent background, text `#94A3B8`, hover text `#F8FAFC`, hover background `rgba(255, 255, 255, 0.05)`.

### Cards & Glass Modules
- Base card background: `rgba(13, 21, 39, 0.75)`.
- Internal padding: `space-lg` (24px) for dashboard widgets, `space-md` (16px) for compact sidebar panels.
- Border: `1px solid rgba(255, 255, 255, 0.08)`.
- Active / In-Progress Card: Left accent border `3px solid #8B5CF6` or an illuminated cyan ring for active study timers.

### Circular Gauges & Progress Rings
- **Track:** `rgba(255, 255, 255, 0.06)` with round stroke caps.
- **Indicator:** Multi-stop conic gradient (`#8B5CF6` to `#3B82F6` to `#06B6D4`) with `filter: drop-shadow(0 0 6px rgba(6, 182, 212, 0.6))`.
- **Center Value:** `headline-md` tabular text centered with supporting `label-sm` metric descriptor.

### Badges & Priority Chips
- **Format:** Fully rounded pill height (24px), horizontal padding `space-sm` (8px).
- **High Priority / Due Soon:** `rgba(244, 63, 94, 0.15)` background, `#FDA4AF` text, `1px solid rgba(244, 63, 94, 0.3)`.
- **Medium Priority:** `rgba(245, 158, 11, 0.15)` background, `#FCD34D` text, `1px solid rgba(245, 158, 11, 0.3)`.
- **Low Priority / Normal:** `rgba(59, 130, 246, 0.15)` background, `#93C5FD` text, `1px solid rgba(59, 130, 246, 0.3)`.

### Input Fields
- Fill: `rgba(11, 15, 25, 0.6)`, Border: `1px solid rgba(255, 255, 255, 0.1)`.
- Text: `#F8FAFC`, Placeholder: `#64748B`.
- Height: 44px on desktop, 48px on mobile for touch accessibility.
- Focus State: Border color `#8B5CF6`, `box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2)`.

### Checkboxes & Habit Trackers
- Size: 20x20px, `0.375rem` (6px) roundedness.
- Unchecked: `rgba(255, 255, 255, 0.05)` fill, `1px solid rgba(255, 255, 255, 0.2)` border.
- Checked: Solid `#8B5CF6` to `#3B82F6` gradient fill, white SVG checkmark, glow: `0 0 10px rgba(139, 92, 246, 0.5)`.

### Lists & Timelines
- Separators use `rgba(255, 255, 255, 0.05)`.
- Hover row state triggers a smooth transition to `background: rgba(255, 255, 255, 0.03)` with `0.5rem` border radius padding.